---
name: Support request
about: Installation of configuration issues
title: ''
labels: question
assignees: ''

---

Make sure you have read [the wiki](https://github.com/niekcandaele/CSGO-RankMe-stats/wiki) before asking questions please!

- **Environment**:
Windows/Linux ? Distro?

- **Description**:
